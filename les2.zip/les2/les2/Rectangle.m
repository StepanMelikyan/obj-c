//
//  Rectangle.m
//  les2
//
//  Created by Stepan on 04.08.2023.
//

#import "Rectangle.h"


@implementation Rectangle

- (instancetype)initWithWidth:(double)width height:(double)height {
    self = [super init];
    if (self) {
        _width = width;
        _height = height;
    }
    return self;
}

- (double)calculateArea {
    return self.width * self.height;
}

- (double)calculatePerimeter {
    return 2 * (self.width + self.height);
}

- (void)printInfo {
    NSLog(@"Прямоугольник:");
    NSLog(@"Ширина: %f", self.width);
    NSLog(@"Высота: %f", self.height);
    NSLog(@"Площадь: %f", [self calculateArea]);
    NSLog(@"Периметр: %f", [self calculatePerimeter]);
}

@end

