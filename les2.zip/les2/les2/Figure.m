//
//  Figure.m
//  les2
//
//  Created by Stepan on 04.08.2023.
//

#import "Figure.h"

@implementation Figure

@end
