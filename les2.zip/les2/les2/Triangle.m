//
//  Triangle.m
//  les2
//
//  Created by Stepan on 04.08.2023.
//


#import "Triangle.h"

@implementation Triangle

- (instancetype)initWithSide1:(double)side1 side2:(double)side2 side3:(double)side3 {
    self = [super init];
    if (self) {
        _side1 = side1;
        _side2 = side2;
        _side3 = side3;
    }
    return self;
}

- (double)calculateArea {
    // Используем формулу Герона для вычисления площади треугольника
    double s = (self.side1 + self.side2 + self.side3) / 2.0;
    return sqrt(s * (s - self.side1) * (s - self.side2) * (s - self.side3));
}

- (double)calculatePerimeter {
    return self.side1 + self.side2 + self.side3;
}

- (void)printInfo {
    NSLog(@"Треугольник:");
    NSLog(@"Сторона 1: %f", self.side1);
    NSLog(@"Сторона 2: %f", self.side2);
    NSLog(@"Сторона 3: %f", self.side3);
    NSLog(@"Площадь: %f", [self calculateArea]);
    NSLog(@"Периметр: %f", [self calculatePerimeter]);
}

@end
