//
//  Circle.m
//  les2
//
//  Created by Stepan on 04.08.2023.
//


#import "Circle.h"

@implementation Circle

- (instancetype)initWithRadius:(double)radius {
    self = [super init];
    if (self) {
        _radius = radius;
    }
    return self;
}

- (double)calculateArea {
    return M_PI * self.radius * self.radius;
}

- (double)calculatePerimeter {
    return 2 * M_PI * self.radius;
}

- (void)printInfo {
    NSLog(@"Круг:");
    NSLog(@"Радиус: %f", self.radius);
    NSLog(@"Площадь: %f", [self calculateArea]);
    NSLog(@"Периметр: %f", [self calculatePerimeter]);
}

@end
