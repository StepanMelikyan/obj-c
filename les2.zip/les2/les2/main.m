//
//  main.m
//  les2
//
//  Created by Stepan on 04.08.2023.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import <Foundation/Foundation.h>
#import "Circle.h"
#import "Rectangle.h"
#import "Triangle.h"


#

// Функция для вывода информации о массиве фигур
void printFiguresInfo(NSArray<Figure *> *figures) {
    for (Figure *figure in figures) {
        [figure printInfo];
        NSLog(@"-------------------------");
    }
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // Создание массива с фигурами
        NSMutableArray<Figure *> *figures = [NSMutableArray array];

        // Добавление фигур в массив
        Circle *circle = [[Circle alloc] initWithRadius:5.0];
        [figures addObject:circle];

        Rectangle *rectangle = [[Rectangle alloc] initWithWidth:4.0 height:6.0];
        [figures addObject:rectangle];

        Triangle *triangle = [[Triangle alloc] initWithSide1:3.0 side2:4.0 side3:5.0];
        [figures addObject:triangle];


        // Вывод информации о фигурах
        printFiguresInfo(figures);
    }
    return 0;
}


