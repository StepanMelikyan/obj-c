//
//  Figure.h
//  les2
//
//  Created by Stepan on 04.08.2023.
//

#import <Foundation/Foundation.h>

@protocol Figure <NSObject>

- (double)calculateArea;
- (double)calculatePerimeter;
- (void)printInfo;

@end

@interface Figure : NSObject <Figure>

// Методы по умолчанию, чтобы имитировать абстрактные методы
- (double)calculateArea {
    return 0.0;
}

- (double)calculatePerimeter {
    return 0.0;
}

- (void)printInfo {
    NSLog(@"Это абстрактная фигура.");
}

@end
