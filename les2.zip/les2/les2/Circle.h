//
//  Circle.h
//  les2
//
//  Created by Stepan on 04.08.2023.
//

#import <Foundation/Foundation.h>

#import "Figure.h"

@interface Circle : Figure

@property (nonatomic, assign) double radius;

- (instancetype)initWithRadius:(double)radius;

@end
