//
//  pthread.m
//  lesson4
//
//  Created by Stepan on 21.08.2023.
//

#import "pthread.h"

@implementation pthread
//1. Создать и запустить PThread поток с любой задачей внутри:
//void *myTask(void *arg) {
//    NSLog(@"PThread выполняется");
//    return NULL;
//}
//
//pthread_t thread;
//pthread_create(&thread, NULL, myTask, NULL);
//pthread_join(thread, NULL);




//2 — Создать Thread поток с любой задачей и убедиться(print thread), что он выполняется не на главном потоке


//NSThread *customThread = [[NSThread alloc] initWithTarget:self selector:@selector(myTask) object:nil];
//[customThread start];
//
//- (void)myTask {
//    if (![NSThread isMainThread]) {
//        NSLog(@"Этот код выполняется на кастомном потоке");
//    } else {
//        NSLog(@"Этот код выполняется на главном потоке");
//    }
//}


//3 — Создать с помощью GCD последовательную и параллельную очередь, в которую передать DispathWorkItem


//
//dispatch_queue_t serialQueue = dispatch_queue_create("com.example.serialQueue", DISPATCH_QUEUE_SERIAL);
//dispatch_queue_t concurrentQueue = dispatch_queue_create("com.example.concurrentQueue", DISPATCH_QUEUE_CONCURRENT);
//
//dispatch_block_t workItem = ^{
//    NSLog(@"Работа выполняется в блоке");
//};
//
//dispatch_async(serialQueue, workItem);      // Последовательная очередь
//dispatch_async(concurrentQueue, workItem);  // Параллельная очередь


//4  Отменить DispatchWorkItem спустя 5 секунд:

//dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
//dispatch_block_t workItem = ^{
//    NSLog(@"PThread выполняется");
//};
//
//dispatch_time_t delayTime = dispatch_time(DISPATCH_TIME_NOW, 5 * NSEC_PER_SEC);
//dispatch_after(delayTime, queue, workItem);
//
//// Для отмены работы
//dispatch_block_cancel(workItem);


//5.Создать несколько Operations и добавить их в последовательную цепочку зависимостей и запустить на NSOperationQueue:
//NSOperationQueue *operationQueue = [[NSOperationQueue alloc] init];
//
//NSOperation *operation1 = [NSBlockOperation blockOperationWithBlock:^{
//    NSLog(@"Operation 1 выполняется");
//}];
//
//NSOperation *operation2 = [NSBlockOperation blockOperationWithBlock:^{
//    NSLog(@"Operation 2 выполняется");
//}];
//
//NSOperation *operation3 = [NSBlockOperation blockOperationWithBlock:^{
//    NSLog(@"Operation 3 выполняется");
//}];
//
//[operation2 addDependency:operation1];
//[operation3 addDependency:operation2];
//
//[operationQueue addOperations:@[operation1, operation2, operation3] waitUntilFinished:NO];
//


@end
