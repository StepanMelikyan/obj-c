//
//  pthread.h
//  lesson4
//
//  Created by Stepan on 21.08.2023.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface pthread : NSObject

@end

NS_ASSUME_NONNULL_END
