//
//  ViewController.h
//  lesson4
//
//  Created by Stepan on 21.08.2023.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

