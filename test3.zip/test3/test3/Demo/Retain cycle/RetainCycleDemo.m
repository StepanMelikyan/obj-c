//
//  RetainCycleDemo.m
//  test3
//
//  Created by artem-ustinov on 07.08.2023.
//

#import "RetainCycleDemo.h"
#import "Person.h"

@implementation RetainCycleDemo

- (void)execute {
//    [self showRetainCount];
//    [self accessToDeallocatedObject];
}

- (void)showRetainCount {
    NSLog(@" ----------- Showing retaint count ----------- ");
    Person *developer = [[Person alloc] init]; // 1

//    NSLog(@"[Person] Retain count after alloc-init: %lu", developer.retainCount);
//
//    [developer retain]; // 2
//
//    NSLog(@"[Person] Retain count after alloc-init: %lu", developer.retainCount);
//
//    [developer release]; // 1
//
//    NSLog(@"[Person] Retain count after alloc-init: %lu", developer.retainCount);
//
//    [developer release]; // 0
    
    NSLog(@"\n");
}

- (void)accessToDeallocatedObject {
    Person *developer = [[Person alloc] init];
//    [developer release];
    NSLog(@"Person developer name %@", developer.name);
    NSLog(@"\n");
}

@end
