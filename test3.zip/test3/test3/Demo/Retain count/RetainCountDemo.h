//
//  RetainCountDemo.h
//  test3
//
//  Created by artem-ustinov on 07.08.2023.
//

#import <Foundation/Foundation.h>
#import "Demo.h"

NS_ASSUME_NONNULL_BEGIN

@interface RetainCountDemo : NSObject <DemoProtocol>

@end

NS_ASSUME_NONNULL_END
