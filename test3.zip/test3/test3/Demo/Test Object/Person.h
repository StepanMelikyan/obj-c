//
//  Person.h
//  test3
//
//  Created by artem-ustinov on 07.08.2023.
//

#import <Foundation/Foundation.h>

//#import "Passport.h"
@class Passport;

NS_ASSUME_NONNULL_BEGIN

@interface Person : NSObject

@property (nonatomic, copy) NSString *name;
@property (nonatomic, assign) NSInteger age;
@property (nonatomic, strong) Passport *passport;

+ (Person *)createPersonWithName:(NSString *)name;
- (instancetype)initWithName:(NSString *)name;

@end

NS_ASSUME_NONNULL_END
