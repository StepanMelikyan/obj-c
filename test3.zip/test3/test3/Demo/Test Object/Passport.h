//
//  Passport.h
//  test3
//
//  Created by artem-ustinov on 07.08.2023.
//

#import <Foundation/Foundation.h>

@class Person;

NS_ASSUME_NONNULL_BEGIN

@interface Passport : NSObject

@property (nonatomic, weak) Person *person;
@property (nonatomic, assign) Person *assignablePerson;

@property (nonatomic, unsafe_unretained) Person *unsafePerson;
@property (nonatomic, weak) Person *weakPerson;


@end

NS_ASSUME_NONNULL_END
