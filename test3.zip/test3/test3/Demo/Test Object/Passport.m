//
//  Passport.m
//  test3
//
//  Created by artem-ustinov on 07.08.2023.
//

#import "Passport.h"

@implementation Passport


- (void)dealloc
{
    NSLog(@"[Passport] %@ is being deallocating", self);

//    [_person release];
//
//    [super dealloc];
}

@end
