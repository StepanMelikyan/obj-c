//
//  Person.m
//  test3
//
//  Created by artem-ustinov on 07.08.2023.
//

#import "Person.h"

@implementation Person

+ (Person *)createPersonWithName:(NSString *)name {
    return [[Person alloc] initWithName:name];
}

- (instancetype)initWithName:(NSString *)name
{
    self = [super init];
    if (self) {
        _name = name;
    }
    return self;
}
//
- (void)dealloc
{
    NSLog(@"[Person] %@ is being deallocating", self);
//
//    [_passport release];
//    [_name release];
//
//    [super dealloc];
}

@end
