//
//  PropertyDemo.m
//  test3
//
//  Created by artem-ustinov on 07.08.2023.
//

#import "PropertyDemo.h"

@implementation PropertyDemo

- (void)execute {
    
}

@end
