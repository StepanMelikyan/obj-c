//
//  ViewController.m
//  test3
//
//  Created by artem-ustinov on 07.08.2023.
//

#import "ViewController.h"
#import "Demo.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    Demo *demo = [[Demo alloc] init];
    [demo execute];
//    [demo release];
}


@end
