//
//  SceneDelegate.h
//  test3
//
//  Created by artem-ustinov on 07.08.2023.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

