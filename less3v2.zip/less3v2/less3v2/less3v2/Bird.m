//
//  Bird.m
//  less3v2
//
//  Created by Stepan on 09.08.2023.
//

#import "Bird.h"

@implementation Bird


- (void)fly {
    NSLog(@"%@ is flying.", self.name);
}

- (void)fall {
    NSLog(@"%@ fell down.", self.name);
}

- (void)eat {
    NSLog(@"%@ is eating.", self.name);
}
@end
