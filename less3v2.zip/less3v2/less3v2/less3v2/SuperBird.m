//
//  SuperBird.m
//  less3v2
//
//  Created by Stepan on 09.08.2023.
//

#import "SuperBird.h"

@implementation SuperBird
- (void)fly {
    NSLog(@"%@ is flying super fast!", self.name);
}

@end
