//
//  SlowBird.m
//  less3v2
//
//  Created by Stepan on 09.08.2023.
//

#import "SlowBird.h"

@implementation SlowBird
- (void)fly {
    NSLog(@"%@ is flying slowly.", self.name);
}

@end
