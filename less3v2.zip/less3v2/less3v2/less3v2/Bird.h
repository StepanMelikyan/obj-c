//
//  Bird.h
//  less3v2
//
//  Created by Stepan on 09.08.2023.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Bird : NSObject
@property (nonatomic, strong) NSString *name;

- (void)fly;
- (void)fall;
- (void)eat;

@end

NS_ASSUME_NONNULL_END
