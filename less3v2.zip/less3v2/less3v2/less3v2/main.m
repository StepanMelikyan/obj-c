//
//  main.m
//  less3v2
//
//  Created by Stepan on 09.08.2023.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "Nest.m"
#import "Bird.m"
#import "SuperBird.h"
#import "SlowBird.h"

int main(int argc, char * argv[]) {
    NSString * appDelegateClassName;
    @autoreleasepool {
        Nest *nest = [[Nest alloc] init];
        Bird *bird1 = [[Bird alloc] init];
        bird1.name = @"Regular Bird";
        SuperBird *superBird = [[SuperBird alloc] init];
        superBird.name = @"Super Bird";
        SlowBird *slowBird = [[SlowBird alloc] init];
        slowBird.name = @"Slow Bird";
        
        nest.bird = bird1;
        
        [nest.bird fly];
        [nest.bird eat];
        [nest.bird fall];
        
        // Create a retain cycle (comment out to avoid the cycle)
        // bird1.nest = nest;
        
        // Clear the retain cycle
        [bird1 setNest:nil];
    }
    return 0;
    
}
