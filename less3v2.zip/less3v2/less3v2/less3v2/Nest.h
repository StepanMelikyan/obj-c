//
//  Nest.h
//  less3v2
//
//  Created by Stepan on 09.08.2023.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Nest : NSObject
@property (nonatomic, weak) id bird;
@property (nonatomic, assign) NSInteger area;
@property (nonatomic, assign) BOOL occupancy;


@end

NS_ASSUME_NONNULL_END
