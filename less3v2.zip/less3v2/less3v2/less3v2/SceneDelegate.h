//
//  SceneDelegate.h
//  less3v2
//
//  Created by Stepan on 09.08.2023.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

