//
//  ViewController.h
//  lesson5
//
//  Created by Stepan on 21.08.2023.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

