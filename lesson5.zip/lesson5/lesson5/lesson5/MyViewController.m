//
//  MyViewController.m
//  lesson5
//
//  Created by Stepan on 21.08.2023.
//

#import <UIKit/UIKit.h>

@interface MyViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@end

