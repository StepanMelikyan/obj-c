//
//  ViewController.m
//  lesson6
//
//  Created by Stepan on 21.08.2023.
//

#import "ViewController.h"
#import "SAMKeychain.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UITextField *dataTextField;
@property (weak, nonatomic) IBOutlet UILabel *resultLabel;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (IBAction)saveToUserDefaults:(id)sender {
    NSString *data = self.dataTextField.text;
    if (data.length > 0) {
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults setObject:data forKey:@"UserData"];
        [defaults synchronize];
        self.resultLabel.text = @"Данные сохранены в UserDefaults";
    } else {
        self.resultLabel.text = @"Введите данные для сохранения";
    }
}

- (IBAction)readFromUserDefaults:(id)sender {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *userData = [defaults objectForKey:@"UserData"];
    if (userData) {
        self.resultLabel.text = [NSString stringWithFormat:@"Данные из UserDefaults: %@", userData];
    } else {
        self.resultLabel.text = @"Данные не найдены в UserDefaults";
    }
}

- (IBAction)saveToKeychain:(id)sender {
    NSString *data = self.dataTextField.text;
    if (data.length > 0) {
        NSError *error = nil;
        [SAMKeychain setPassword:data forService:@"MyApp" account:@"User" error:&error];
        if (!error) {
            self.resultLabel.text = @"Данные сохранены в Keychain";
        } else {
            self.resultLabel.text = [NSString stringWithFormat:@"Ошибка: %@", error.localizedDescription];
        }
    } else {
        self.resultLabel.text = @"Введите данные для сохранения";
    }
}

- (IBAction)readFromKeychain:(id)sender {
    NSError *error = nil;
    NSString *data = [SAMKeychain passwordForService:@"MyApp" account:@"User" error:&error];
    if (!error) {
        self.resultLabel.text = [NSString stringWithFormat:@"Данные из Keychain: %@", data];
    } else {
        self.resultLabel.text = @"Данные не найдены в Keychain";
    }
}

- (IBAction)saveToPropertyList:(id)sender {
    NSString *data = self.dataTextField.text;
    if (data.length > 0) {
        NSDictionary *dataDict = @{@"UserData": data};
        NSString *path = [self plistPath];
        if ([dataDict writeToFile:path atomically:YES]) {
            self.resultLabel.text = @"Данные сохранены в Property List";
        } else {
            self.resultLabel.text = @"Ошибка при сохранении в Property List";
        }
    } else {
        self.resultLabel.text = @"Введите данные для сохранения";
    }
}

- (IBAction)readFromPropertyList:(id)sender {
    NSString *path = [self plistPath];
    NSDictionary *dataDict = [NSDictionary dictionaryWithContentsOfFile:path];
    NSString *userData = dataDict[@"UserData"];
    if (userData) {
        self.resultLabel.text = [NSString stringWithFormat:@"Данные из Property List: %@", userData];
    } else {
        self.resultLabel.text = @"Данные не найдены в Property List";
    }
}

- (NSString *)plistPath {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths firstObject];
    NSString *plistPath = [documentsDirectory stringByAppendingPathComponent:@"UserData.plist"];
    return plistPath;
}

@end
