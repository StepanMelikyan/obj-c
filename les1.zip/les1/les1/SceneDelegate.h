//
//  SceneDelegate.h
//  les1
//
//  Created by Stepan on 04.08.2023.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

