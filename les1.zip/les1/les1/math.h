//
//  math.h
//  les1
//
//  Created by Stepan on 04.08.2023.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface math : NSObject

+ (void)solveQuadraticEquationWithA:(double)a b:(double)b c:(double)c;

@end


NS_ASSUME_NONNULL_END
