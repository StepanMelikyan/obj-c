//
//  MaxNumberFinder.h
//  les1
//
//  Created by Stepan on 04.08.2023.
//

#import <Foundation/Foundation.h>

@interface MaxNumberFinder : NSObject

+ (double)findMaxNumberFrom:(double)num1 number2:(double)num2 number3:(double)num3;

@end

