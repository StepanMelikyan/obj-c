//
//  ViewController.h
//  les1
//
//  Created by Stepan on 04.08.2023.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

