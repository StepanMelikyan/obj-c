//
//  main.m
//  les1
//
//  Created by Stepan on 04.08.2023.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import <Foundation/Foundation.h>
#import "MaxNumberFinder.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        double number1, number2, number3;

        NSLog(@"Введите первое число:");
        scanf("%lf", &number1);

        NSLog(@"Введите второе число:");
        scanf("%lf", &number2);

        NSLog(@"Введите третье число:");
        scanf("%lf", &number3); 

        double maxNumber = [MaxNumberFinder findMaxNumberFrom:number1 number2:number2 number3:number3];
        NSLog(@"Наибольшее число: %f", maxNumber);
    }
    return 0;
}

