//
//  math.m
//  les1
//
//  Created by Stepan on 04.08.2023.
//

#import "math.h"

@implementation math


+ (void)solveQuadraticEquationWithA:(double)a b:(double)b c:(double)c {
    double discriminant = b * b - 4 * a * c;

    if (discriminant > 0) {
        double x1 = (-b + sqrt(discriminant)) / (2 * a);
        double x2 = (-b - sqrt(discriminant)) / (2 * a);
        NSLog(@"Уравнение имеет два корня: x1 = %f, x2 = %f", x1, x2);
    } else if (discriminant == 0) {
        double x = -b / (2 * a);
        NSLog(@"Уравнение имеет один корень: x = %f", x);
    } else {
        NSLog(@"Уравнение не имеет вещественных корней.");
    }
}

@end



