//
//  MaxNumberFinder.m
//  les1
//
//  Created by Stepan on 04.08.2023.
//

#import "MaxNumberFinder.h"

@implementation MaxNumberFinder

+ (double)findMaxNumberFrom:(double)num1 number2:(double)num2 number3:(double)num3 {
    double maxNumber = num1;

    if (num2 > maxNumber) {
        maxNumber = num2;
    }

    if (num3 > maxNumber) {
        maxNumber = num3;
    }

    return maxNumber;
}

@end

